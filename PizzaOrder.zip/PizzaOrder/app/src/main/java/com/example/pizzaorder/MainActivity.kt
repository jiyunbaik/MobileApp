package com.example.pizzaorder

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

// CPAN200RNB
// Oct 6th 2020
// Week5 Pizza Order
// Created by Ji Yun Baik (N01383344)

private const val TAG = "MainActivity"
private const val KEY_RESULT = "total"
private var total: String = ""

class MainActivity : AppCompatActivity() {

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i(TAG, "OnCreate() was called")
        setContentView(R.layout.activity_main)

        // variables set for price of pizza, topping and tax
        var pizzaSizePrice: Double = 0.0
        var meatPrice: Double = 0.0
        var cheesePrice: Double = 0.0
        var veggiePrice: Double = 0.0
        val tax: Double = 1.13

        // will show stored data
        if(savedInstanceState!=null) {
            total = savedInstanceState.getString(KEY_RESULT).toString()
            totalPrice.text = "Total Price : $$total"
        }

        // function to calculate total price and output with 2 decimal points
        fun calculateTotal() {
            var cal = (pizzaSizePrice+meatPrice+cheesePrice+veggiePrice)*tax
            total = String.format("%.2f", cal)
            totalPrice.text = "Total Price : $$total"
        }

        // function to clear all input data
        fun clear(){
            radioGroup.clearCheck()
            cbMeat.isChecked = false
            cbCheese.isChecked = false
            cbVeggie.isChecked = false
            switchDelivery.isChecked = false
            delivery.text.clear()
            total = ""
            totalPrice.text = "Total Price : "
        }

        // choose the size of pizza and give proper price to variable and calculate total and output
        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            if (checkedId == R.id.rbSmall){
//                Toast.makeText(this, rbSmall.text.toString(), Toast.LENGTH_SHORT).show()
                pizzaSizePrice = 9.0
            }
            if (checkedId == R.id.rbMedium){
//                Toast.makeText(this, rbMedium.text.toString(), Toast.LENGTH_SHORT).show()
                pizzaSizePrice = 10.0
            }
            if (checkedId == R.id.rbLarge){
//                Toast.makeText(this, rbLarge.text.toString(), Toast.LENGTH_SHORT).show()
                pizzaSizePrice = 11.0
            }
            calculateTotal()
        }

        // add or remove meat topping and calculate total and output
        cbMeat.setOnCheckedChangeListener { _, isChecked ->
            meatPrice = if (isChecked) {
                2.0
            } else {
                0.0
            }
            calculateTotal()
        }

        // add or remove cheese topping and calculate total and output
        cbCheese.setOnCheckedChangeListener { _, isChecked ->
            cheesePrice = if (isChecked) {
                2.0
            } else {
                0.0
            }
            calculateTotal()
        }

        // add or remove veggie topping and calculate total and output
        cbVeggie.setOnCheckedChangeListener { _, isChecked ->
            veggiePrice = if (isChecked) {
                2.0
            } else {
                0.0
            }
            calculateTotal()
        }

        //show textbox available with hint to input address with OK button when switch on
        switchDelivery.setOnCheckedChangeListener { _, onSwitch ->
            if (onSwitch){
                delivery.visibility = View.VISIBLE
                delivery.hint = "Please enter address here"
                btnOk.visibility = View.VISIBLE
            } else {
                delivery.visibility = View.INVISIBLE
                btnOk.visibility = View.INVISIBLE
            }
        }

        // Upon button click,
        // if all required inputs are filled, show short msg with delivery info and clear all input
        // if address is not filled, will show Toast asking for input
        // if pizza size is not selected, will show Toast asking for input
        btnOk.setOnClickListener {
            when {
                delivery.text.isEmpty() -> {
                    Toast.makeText(this, "Please enter your address before clicking OK", Toast.LENGTH_SHORT).show()
                }
                radioGroup.checkedRadioButtonId == -1 -> {
                    Toast.makeText(this, "Please choose your pizza size", Toast.LENGTH_SHORT).show()
                }
                else -> {
                    var deliveryMsg = "Your pizza will be delivered to " + delivery.text + " shortly"
                    Toast.makeText(this, deliveryMsg, Toast.LENGTH_SHORT).show()
                    clear()
                }
            }
        }

    }

    override fun onStart() {
        super.onStart()
        Log.i(TAG, "OnStart() was called")
    }

    override fun onPause() {
        super.onPause()
        Log.i(TAG, "OnPause() was called")
    }

    override fun onStop() {
        super.onStop()
        Log.i(TAG, "OnStop() was called")
    }

    override fun onResume() {
        super.onResume()
        Log.i(TAG, "OnResume() was called")
    }

    override fun onRestart() {
        super.onRestart()
        Log.i(TAG, "onRestart() was called")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "onDestroy() was called")
    }

    override fun onSaveInstanceState(savedInstanceState: Bundle) {
        super.onSaveInstanceState(savedInstanceState)
        Log.i(TAG, "OnSaveInstanceState() was called")
        savedInstanceState.putString(KEY_RESULT, total)
    }

}