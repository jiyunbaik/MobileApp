package com.example.pizzaorder

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.customer_info.*

// CPAN200RNB
// Oct 6th 2020
// Week5 Pizza Order
// Created by Ji Yun Baik (N01383344)

// Nov 1st 2020
// Updated with file storage

class CustomerInfo : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.customer_info)

        val pref = getPreferences(MODE_PRIVATE)
        val name = pref.getString("NAME", "")
        val phone = pref.getInt("PHONE", 0)
        editName.setText(name)
        editPhone.setText(phone.toString())
    }

    fun onNext(view: View) {
            // check if information is empty
        if (editName.text.isEmpty() || editPhone.text.isEmpty()){
            showToast("Please enter your information")
        } else {
            // check if phone number is integer
            // if not, will toast error message
            try {
                Integer.parseInt(editPhone.text.toString())

                // create shared preferences file
                val pref = getPreferences(MODE_PRIVATE)
                val editor = pref.edit()
                val name = editName.text.toString()
                val phone = editPhone.text.toString().toInt()
                editor.putString("NAME", editName.text.toString())
                editor.putInt("PHONE", editPhone.text.toString().toInt())

                editor.commit()

                // saves data using intent to bring data to pizza order page
                val intent = Intent(this@CustomerInfo, PizzaOrder::class.java)
                intent.putExtra("Name", name)
                intent.putExtra("Phone", phone)

                startActivity(intent)
            }
            catch (e: NumberFormatException){
                e.printStackTrace()
                showToast("Please enter valid phone number")
            }
        }
    }

    // Clear all input fields
    fun onClear(view: View) {
        val pref = getPreferences(MODE_PRIVATE)
        val editor = pref.edit()

        editor.clear()
        editor.commit()

        editName.setText("")
        editPhone.setText("")
    }

    // direct to order history page
    fun onOrderHistory(view: View) {
        val intent = Intent(this@CustomerInfo, OrderHistory::class.java)
        startActivity(intent)
    }

    // function to show toast
    fun Context.showToast(text: CharSequence, duration: Int = Toast.LENGTH_LONG) {
        Toast.makeText(this, text, duration).show()
    }

}