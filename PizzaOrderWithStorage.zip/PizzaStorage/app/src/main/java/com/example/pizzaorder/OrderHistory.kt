package com.example.pizzaorder

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_order_history.*
import java.io.BufferedReader
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.InputStreamReader
import java.lang.StringBuilder

class OrderHistory : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_history)

        // read data and output to text box
        // if there's no file found, will show "Order History Does Not Exist"
        val filename = "OrderHistory.txt"
        var fileInputStream: FileInputStream? = null

        try {
            fileInputStream = openFileInput(filename)
            var inputStreamReader: InputStreamReader = InputStreamReader(fileInputStream)
            val bufferedReader: BufferedReader = BufferedReader(inputStreamReader)

            val stringBuilder: StringBuilder = StringBuilder()
            var text: String? = null

            while ({text = bufferedReader.readLine(); text}()!=null){
                stringBuilder.append(text)
                stringBuilder.append("\n")
            }
            txtOrderHistory.setText(stringBuilder.toString()).toString()
        }
        catch (e: FileNotFoundException){
            e.printStackTrace()
            txtOrderHistory.setText("Order History Does Not Exist")
        }
        catch (e: Exception){
            e.printStackTrace()
        }
    }
}