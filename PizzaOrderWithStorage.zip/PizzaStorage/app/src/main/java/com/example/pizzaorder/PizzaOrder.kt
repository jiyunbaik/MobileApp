package com.example.pizzaorder

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_order_history.*
import kotlinx.android.synthetic.main.pizza_order.*
import java.io.*
import java.lang.Exception
import java.lang.StringBuilder

// CPAN200RNB
// Oct 6th 2020
// Week5 Pizza Order
// Created by Ji Yun Baik (N01383344)

// Nov 1st 2020
// Updated with file storage

private const val KEY_RESULT = "total"
private var total: String = ""

class PizzaOrder : AppCompatActivity() {

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.pizza_order)

        //get intent object and data from intent
        val intent = getIntent()
        val name = intent.getStringExtra("Name")
        val phone = intent.getIntExtra("Phone", 0)

        // variables set for price of pizza, topping and tax
        var pizzaSizePrice: Double = 0.0
        var meatPrice: Double = 0.0
        var cheesePrice: Double = 0.0
        var veggiePrice: Double = 0.0
        val tax: Double = 1.13
        var size = ""
        var topping = ""
        var meatTopping = ""
        var cheeseTopping = ""
        var veggieTopping = ""

        // will show stored data
        if(savedInstanceState!=null) {
            total = savedInstanceState.getString(KEY_RESULT).toString()
            totalPrice.text = "Total Price : $$total"
        }

        // function to calculate total price and output with 2 decimal points
        fun calculateTotal() {
            var cal = (pizzaSizePrice+meatPrice+cheesePrice+veggiePrice)*tax
            total = String.format("%.2f", cal)
            totalPrice.text = "Total Price : $$total"
        }

        // function to clear all input data
        fun clear(){
            radioGroup.clearCheck()
            cbMeat.isChecked = false
            cbCheese.isChecked = false
            cbVeggie.isChecked = false
            switchDelivery.isChecked = false
            delivery.text.clear()
            total = ""
            totalPrice.text = "Total Price : "
        }

        // choose the size of pizza and give proper price to variable and calculate total and output
        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            if (checkedId == R.id.rbSmall){
//                Toast.makeText(this, rbSmall.text.toString(), Toast.LENGTH_SHORT).show()
                pizzaSizePrice = 9.0
                size = "Small"
            }
            if (checkedId == R.id.rbMedium){
//                Toast.makeText(this, rbMedium.text.toString(), Toast.LENGTH_SHORT).show()
                pizzaSizePrice = 10.0
                size = "Medium"
            }
            if (checkedId == R.id.rbLarge){
//                Toast.makeText(this, rbLarge.text.toString(), Toast.LENGTH_SHORT).show()
                pizzaSizePrice = 11.0
                size = "Large"
            }
            calculateTotal()
        }

        // add or remove meat topping and calculate total and output
        cbMeat.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                meatPrice = 2.0
                meatTopping = "Meat"
            } else {
                meatPrice = 0.0
                meatTopping = ""
            }
            calculateTotal()
        }

        // add or remove cheese topping and calculate total and output
        cbCheese.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                cheesePrice = 2.0
                cheeseTopping = "Cheese"
            } else {
                cheesePrice = 0.0
                cheeseTopping = ""
            }
            calculateTotal()
        }

        // add or remove veggie topping and calculate total and output
        cbVeggie.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                veggiePrice = 2.0
                veggieTopping = "Veggie"
            } else {
                veggiePrice = 0.0
                veggieTopping = ""
            }
            calculateTotal()
        }

        //show textbox available with hint to input address with OK button when switch on
        switchDelivery.setOnCheckedChangeListener { _, onSwitch ->
            if (onSwitch){
                delivery.visibility = View.VISIBLE
                delivery.hint = "Please enter address here"
            } else {
                delivery.visibility = View.INVISIBLE
            }
        }

        // Upon button click,
        // if all required inputs are filled, show short msg with delivery info and clear all input
        // if address is not filled while delivery requested, will show Toast asking for input
        // if pizza size is not selected, will show Toast asking for input
        // and save order to file OrderHistory.txt
        btnSubmitOrder.setOnClickListener {
            when {
                radioGroup.checkedRadioButtonId == -1 -> {
                    showToast("Please choose your pizza size")
                }
                (delivery.text.isEmpty() && switchDelivery.isChecked) -> {
                    showToast("Please enter your address before clicking OK")
                }
                else -> {
                    var orderMsg = ""
                    if(switchDelivery.isChecked) {
                        orderMsg = "Your pizza will be delivered to " + delivery.text + " shortly"
                    }else{
                        orderMsg = "Your pizza will be ready shortly for pick up"
                    }
                    showToast(orderMsg)

                    val file = "OrderHistory.txt"
                    // check if there is order history
                    // if yes, set data to txtHidden (used to keep old data)
                    var fileInputStream: FileInputStream? = null
                    try {
                        fileInputStream = openFileInput(file)
                        var inputStreamReader: InputStreamReader = InputStreamReader(fileInputStream)
                        val bufferedReader: BufferedReader = BufferedReader(inputStreamReader)

                        val stringBuilder: StringBuilder = StringBuilder()
                        var text: String? = null

                        while ({text = bufferedReader.readLine(); text}()!=null) {
                            stringBuilder.append(text)
                            stringBuilder.append("\n")
                        }
                        txtHidden.setText(stringBuilder.toString()).toString()
                    }
                    catch (e: FileNotFoundException){
                        e.printStackTrace()
                    }

                    // save old + new data to file and clear all selection
                    val data = txtHidden.text.toString()+name+" "+phone+" "+size+" "+meatTopping+" "+cheeseTopping+" "+veggieTopping+" $"+total
                    val fileOutputStream: FileOutputStream

                    try {
                        fileOutputStream = openFileOutput(file, Context.MODE_PRIVATE)
                        fileOutputStream.write(data.toByteArray())
                    } catch (e: FileNotFoundException) {
                        e.printStackTrace()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                    clear()
                }
            }
        }

    }

    override fun onSaveInstanceState(savedInstanceState: Bundle) {
        super.onSaveInstanceState(savedInstanceState)
        savedInstanceState.putString(KEY_RESULT, total)
    }

    fun Context.showToast(text: CharSequence, duration: Int = Toast.LENGTH_LONG) {
        Toast.makeText(this, text, duration).show()
    }
}